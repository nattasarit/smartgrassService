﻿using System.Web;

namespace webservice
{
	public class Global : HttpApplication
	{
		protected void Application_Start()
		{
		}
	}
}
